# Dreamy-Cafe
# Requirements and Specifications
The assignment requires that you develop a website for Dreamy Cafe, a coffee shop. The director of
Dreamy Cafe, Ms Dreamy, is interested in developing a website that allows users to register and place
orders for coffee online.

# Live Site:
https://dreamycafe.netlify.app/
